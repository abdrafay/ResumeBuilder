import {createContext} from "react"
const DispatchContext = createContext()
export default DispatchContext
